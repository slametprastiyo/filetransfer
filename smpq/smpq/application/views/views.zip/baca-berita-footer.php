<script src="<?= base_url(); ?>public/assets/js/baca-berita-script.js"></script>
</body>

</html>