<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?= base_url(); ?>public/assets/css/output.css">
    <link rel="stylesheet" href="<?= base_url(); ?>public/assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Protest+Strike&display=swap" rel="stylesheet">
</head>

<body class="font-poppins text-primary">
    <div
        class="hidden visi-misi w-full h-screen bg-black z-50 bg-opacity-[0.75] fixed overflow-y-scroll backdrop-blur-xl flex justify-center">
        <div class="w-9/12 md:w-2/5 sm:w-10/12 lg:2/5 absolute ">
            <img src="<?= base_url() ?>public/assets/images/visi-misi-bg-transparent.webp" class="w-full" alt="">
            <div
                class="close-btn absolute right-2 top-2 bg-white text-black w-6 rounded-full aspect-square flex justify-center items-center hover:cursor-pointer scale-125">
                x</div>
        </div>
    </div>

    <header class="fixed w-full z-40">
        <div class="w-full bg-white">08080808080</div>
        <div class="w-full py-2 px-4 flex justify-between items-center">
            <div class="logo-smp">
                <img src="<?= base_url() ?>public/assets/images/logo.png" alt="" class="w-14">
            </div>
            <nav>
                <div class="relative inline-block text-left menu mx-3">
                    <div>
                        <button id=""
                            class="inline-flex justify-center w-full px-4 py-2 text-sm font-medium text-white bg-green-500 rounded-md hover:border-solid hover:border-green-500 hover:border-2 hover:bg-transparent focus:outline-none transition-all">
                            Options

                        </button>
                    </div>
                    <div id=""
                        class="dropdown-menu hidden origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                        <div class="py-1" role="menu" aria-orientation="vertical" aria-labelledby="">
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                role="menuitem">Account settings</a>
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                role="menuitem">Support</a>
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                role="menuitem">License</a>
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                role="menuitem">Sign
                                out</a>
                        </div>
                    </div>
                </div>
                <div class="relative inline-block text-left menu mx-3">
                    <div>
                        <button id=""
                            class="inline-flex justify-center w-full px-4 py-2 text-sm font-medium text-primary rounded-md hover:bg-orange-400 hover:text-white focus:outline-none">
                            Options

                        </button>
                    </div>
                    <div id=""
                        class="dropdown-menu hidden origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                        <div class="py-1" role="menu" aria-orientation="vertical" aria-labelledby="">
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                role="menuitem">Account settings</a>
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                role="menuitem">Support</a>
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                role="menuitem">License</a>
                            <div class="relative inline-block text-left menu mx-3">
                                <div>
                                    <button id=""
                                        class="inline-flex justify-center w-full px-4 py-2 text-sm font-medium text-white bg-green-500 rounded-md hover:border-solid hover:border-green-500 hover:border-2 hover:bg-transparent focus:outline-none transition-all">
                                        Options

                                    </button>
                                </div>
                                <div id=""
                                    class="dropdown-menu hidden origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                                    <div class="py-1" role="menu" aria-orientation="vertical" aria-labelledby="">
                                        <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                            role="menuitem">Account settings</a>
                                        <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                            role="menuitem">Support</a>
                                        <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                            role="menuitem">License</a>
                                        <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                            role="menuitem">Sign
                                            out</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            <nav class="mobile md:hidden w-full h-0 overflow-hidden bg-black/50 flex flex-col  relative  transition-all ">
            <div class="  bg-primary w-full p-2 border-b border-black">
                <a href="#galeri" class="internal-link">Galeri</a>
            </div>
            <div class="  bg-primary w-full p-2 border-b border-black">
                <a href="">link 1</a>
            </div>
            <div class="  bg-primary w-full p-2 border-b border-black">
                <a href="" class="parent-link">link 3</a>
                <div class="menu-child bg-black p-2 w-full hidden flex flex-col items-start">
                    <div class="  w-full p-2">
                        <a href="">link 1</a>
                    </div>
                    <div class="  w-full p-2">
                        <a href="">link 1</a>
                    </div>
                    <div class="  w-full p-2">
                        <a href="">link 1</a>
                    </div>
                </div>
            </div>
            <div class="  bg-primary w-full p-2 border-b border-black">
                <a href="" class="parent-link">link 4</a>
                <div class="menu-child bg-black p-2 w-full hidden flex flex-col items-start">
                    <div class="  w-full p-2">
                        <a href="">link 1</a>
                    </div>
                    <div class="  w-full p-2">
                        <a href="">link 1</a>
                    </div>
                    <div class="  w-full p-2">
                        <a href="">link 1</a>
                    </div>
                </div>
            </div>
            <div class="  bg-primary w-full p-2 border-b border-black">
                <a href="" class="parent-link">link 4</a>
                <div class="menu-child bg-black p-2 w-full hidden flex flex-col items-start">
                    <div class="  w-full p-2">
                        <a href="">link 1</a>
                    </div>
                    <div class="  w-full p-2">
                        <a href="">link 1</a>
                    </div>
                    <div class="  w-full p-2">
                        <a href="">link 1</a>
                    </div>
                </div>
            </div>
            <div class="  bg-primary w-full p-2 border-b border-black">
                <a href="#berita" class="internal-link">Berita</a>
            </div>
        </nav>
        </div>
    </header>
    <section
        class="relative w-full mx-auto min-h-screen bg-[url('../images/hero-bg.png')] bg-no-repeat bg-cover overflow-hidden flex justify-center items-center flex-col">
        <div class="absolute z-0 w-full h-screen bg-black opacity-85"></div>
        <img src="<?= base_url() ?>public/assets/images/logo.png" alt="logo smp qur'an Almuanawiyah"
            class="z-20 max-w-28">
        <h1 class="z-20 text-[50px] text-center ">SMP Qur'an Almuanawiyah</h1>
        <p class="z-20 text-center text-white">"Sebaik-baik Kalian Adalah Orang Yang Belajar Al-Quran dan
            Mengajarkannya" HR. Bukhari, Abu Daud, dan Tirmidzi</p>
        <div
            class="visi-misi-btn border-solid border-2 border-white mt-16 z-20 px-4 py-2 text-white rounded-full opacity-50 hover:cursor-pointer hover:opacity-100 transition-all">
            Visi & Misi</div>
    </section>
    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Id omnis tempora animi adipisci dicta explicabo expedita
    cumque mollitia! Obcaecati tempora quis ea deserunt perspiciatis necessitatibus minima repudiandae nulla quaerat
    quam? Qui aliquam laboriosam iste aut fuga voluptatum repellendus assumenda. Labore, quod error? Minima inventore
    tenetur exercitationem omnis nisi, ipsam quas. Optio, ullam impedit perspiciatis rerum, ratione aspernatur beatae at
    minima eligendi voluptatum quae possimus blanditiis ab maxime laborum praesentium tempore vitae nostrum voluptatibus
    veniam! Ipsa placeat aut labore tenetur aliquam, sed eveniet obcaecati nobis voluptatibus rerum praesentium sunt
    officia. Laborum perferendis repellendus, necessitatibus rem assumenda est. Animi quibusdam dolores sunt ad ipsum
    eveniet. Voluptas, magnam ipsum totam nisi sequi facilis ea ullam quidem, hic voluptatem magni! Eos cumque excepturi
    tempora, ducimus deleniti magni laudantium exercitationem natus, ea inventore, alias quae! Unde quod consequatur
    repellendus incidunt ab similique illo eius, architecto tempora praesentium. Temporibus est minima eius placeat
    dolorum nam eum quibusdam amet molestias natus officiis voluptas earum tempore odio eveniet voluptatem dolore
    praesentium accusantium, ducimus modi. Ratione nemo deleniti maiores dolore culpa consectetur iure recusandae
    exercitationem veritatis saepe vero ipsa consequuntur, facilis dignissimos minima, earum error. Atque deleniti ipsum
    labore, reprehenderit placeat, aspernatur commodi mollitia aliquam molestiae vitae cupiditate expedita consequuntur
    fugit corporis pariatur inventore tempora corrupti alias ullam amet maiores sapiente? Enim sed cumque, sequi
    reiciendis explicabo dolorum, velit iste sapiente labore eius debitis animi eaque quis. Porro praesentium reiciendis
    earum suscipit labore provident cupiditate nostrum quod, possimus quam harum debitis distinctio dolor iste est unde
    doloribus ipsa architecto vero nemo atque laboriosam perspiciatis nulla odit. Eaque excepturi ad facere veritatis,
    illo dolorum architecto ratione suscipit amet praesentium? Harum, nesciunt quo dicta et autem ipsum dolorem,
    necessitatibus quibusdam minus vel nulla aperiam accusamus praesentium iusto cum possimus ex officia! Non incidunt,
    dolor inventore sunt soluta ratione. Officiis temporibus modi perspiciatis nostrum eum eveniet nesciunt autem
    consequuntur impedit dolore, alias, dolorum tempore hic tempora recusandae dignissimos voluptatibus eius nulla vel?
    Dolore, deleniti ad corporis ipsa eaque, quae, consequuntur tenetur debitis unde fugiat in dolores! Quisquam quia
    enim recusandae atque vitae quibusdam error accusamus, veritatis iure nihil, natus suscipit dolor! Praesentium,
    obcaecati quae? Dolor totam repellendus quidem autem quibusdam voluptas voluptate quos earum nihil, eius a
    reiciendis repudiandae blanditiis illum nesciunt, corrupti optio. Voluptates tempore non rem eius mollitia unde
    sequi ullam, dignissimos fuga similique iusto ducimus ipsum beatae, possimus ipsam nulla veritatis. Inventore
    consequatur suscipit libero dolor magnam nemo fugiat deleniti repellendus reiciendis dolorem distinctio ut aliquid
    maxime, animi ab ipsum voluptatum nesciunt. Asperiores assumenda soluta totam, placeat modi quibusdam eius minus
    debitis dolorum illum fuga voluptate quis ipsum, rerum quisquam quod minima? Assumenda id quasi saepe asperiores
    nihil accusantium nesciunt perferendis veniam nostrum reprehenderit quibusdam iste exercitationem aperiam itaque
    repellendus adipisci dignissimos, quae vel. Ipsa recusandae, non autem vitae aliquam magnam laborum dolor repellat
    excepturi fugiat, eaque expedita quia inventore cum sit mollitia ipsam. Ex dicta iste soluta error fugit odio
    eveniet architecto fuga saepe minima id iusto voluptas autem, rem deserunt a! Exercitationem, id voluptate repellat
    in est blanditiis sit. Facilis ab neque consectetur nobis. Voluptates, similique illo. Labore similique corporis
    animi atque non corrupti repellendus voluptatem delectus quas sequi, quasi, quam itaque, accusantium vero rerum
    incidunt. Aliquam, impedit ipsa magni repudiandae obcaecati quo quibusdam eum accusantium. Eum saepe eaque quasi
    magni amet nostrum repudiandae laboriosam! Perspiciatis ipsa facilis inventore dolore a aspernatur laudantium
    dignissimos aut, iure fuga blanditiis culpa magni molestias. At ab magni harum molestias odit voluptatibus aliquam
    labore porro corporis quibusdam placeat blanditiis quo dolorum qui impedit modi hic, rem, fugit adipisci,
    necessitatibus dolor quasi laudantium. Laborum reiciendis mollitia nesciunt consequuntur libero ducimus voluptatum,
    dicta officiis atque dignissimos ipsum accusantium tempore velit quas aspernatur aperiam ullam voluptates minus
    deserunt at. Nesciunt magni harum eaque inventore voluptatum iste, saepe aliquam modi eveniet explicabo quo
    aspernatur sequi maxime delectus esse vitae quisquam quam corporis, enim corrupti ea totam. Reprehenderit illum
    dicta incidunt minima nihil accusantium, perferendis maiores saepe, id aspernatur similique sapiente dolore. Esse
    sed, nemo repellat asperiores soluta consectetur sapiente inventore unde rem voluptatibus, illum nisi. Rem nesciunt
    nihil praesentium ipsam ratione repudiandae sit repellat necessitatibus quas esse ut nisi, odio commodi eius, quasi
    nam provident inventore. Soluta illum laborum nam. Aut officiis ullam quo iusto, odio perspiciatis quasi! Eius
    nostrum praesentium minus quasi dignissimos voluptas ad ipsum ipsam provident quae recusandae sit omnis illum
    suscipit, assumenda odit debitis architecto a, dolor fugiat ex esse facere iusto atque. Saepe aspernatur aliquid non
    doloremque delectus illum nisi commodi itaque porro, quia quibusdam sed nemo adipisci cum repellat perferendis,
    sequi nesciunt tempore quos sapiente earum officiis ut natus ipsam! Consequatur totam officiis porro eveniet sequi
    doloribus, earum quasi debitis a at. Distinctio est, aspernatur corporis fuga deleniti optio tempore qui odio quas
    quod aliquid hic minus, sit soluta accusamus nemo tenetur doloribus amet unde, error odit? Minus qui temporibus,
    tempore aliquid tenetur ad commodi excepturi. Animi neque tempore ducimus praesentium sint? Fugiat voluptate
    quisquam ducimus explicabo libero similique asperiores consequatur! Incidunt suscipit asperiores optio non commodi
    sunt, assumenda nam dignissimos esse dicta repellat praesentium autem expedita repellendus ipsam! Nam velit quas
    facilis quia aliquam non, ea perferendis molestiae sequi obcaecati. Provident obcaecati eaque quod repellendus
    officia assumenda harum id voluptas nihil maiores sunt repellat porro quas blanditiis, perspiciatis cupiditate velit
    adipisci optio soluta dolor cumque! Dolorem est esse nobis! Voluptas delectus recusandae aliquam numquam officia
    veritatis consequuntur dolorem fuga officiis, tempora deserunt a similique aut sunt, blanditiis architecto
    consectetur nemo distinctio! Quae quas blanditiis, nisi, nesciunt explicabo quibusdam culpa hic ad error tenetur
    fugit natus delectus quo tempore voluptatum magni iusto labore accusamus, voluptatem commodi veritatis? Eveniet
    libero, fugit nemo architecto sequi consequuntur veritatis asperiores officiis blanditiis nisi quae ea debitis
    possimus dignissimos minima, vel eaque dolore neque! Consequatur mollitia alias deserunt voluptatem! Deserunt nemo
    maiores modi pariatur. Quia placeat deserunt quisquam, expedita quasi minima nemo libero. Quas aut animi sunt,
    laboriosam eius molestias perferendis. Atque, aliquid quisquam, laborum voluptas unde provident, pariatur minus
    voluptatem libero consequatur esse obcaecati voluptatibus distinctio quae optio vel velit labore debitis vitae.
    <script src="<?= base_url(); ?>public/assets/js/script.js"></script>
</body>

</html>