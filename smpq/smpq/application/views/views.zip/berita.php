<header
    class="h-[300px] flex justify-center items-center bg-[url('../images/profil-hero-bg.jpg')] bg-no-repeat bg-cover  pt-12">
    <h1 class="uppercase text-white font-bold text-5xl">Berita</h1>
</header>
<div class="berita-container flex flex-col md:flex-row  bg-gray-100 pb-20">
    <section class="pt-10 px-5 ">
        <div class="berita-container h-fit w-full grid gap-1 lg:grid-cols-2">
            <?php if ($results != null): ?>
                <?php foreach ($results as $result): ?>
                    <div class="berita-card relative bg-cover shadow-md rounded-2xl bg-white w-full flex p-3  transition-all duration-300 ease-out"
                        data-thumb="<?= $result['thumb']; ?>" data-hd="<?= $result['hd']; ?>" id="<?= $result['id']; ?>">
                        <div class="news-image-container relative w-40 aspect-square overflow-hidden rounded-lg">
                            <img class="gambar-berita  object-cover object-center hd h-full w-full rounded-md  absolute hidden">
                            <img class="gambar-berita  object-cover object-center thumb h-40 w-full rounded-md absolute ">
                            <div class="overlay w-full h-full bg-black absolute top-0 left-0 flex justify-center items-center">
                                <img src="<?= base_url() ?>public/assets/images/loader.svg" class="w-5 h-5 rounded-lg" alt="">
                            </div>
                        </div>
                        <div class="detail  pl-2 w-full flex flex-col justify-between">
                            <div class="main flex flex-col">
                                <div class="berita-judul font-medium text-wrap"><?= $result['title']; ?></div>
                                <!-- <p class="berita-short text-sm max-h-52 overflow-hidden">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia vero repellat doloremque debitis blandriatur sit?</p> -->
                            </div>
                            <div class="footer flex justify-between font-sans items-center">
                                <div class="detail-berita  text-xxs text-gray-600">
                                    <div class="tanggal   inline-block">01/09/2024</div>
                                    <div class="view  inline-block ml-2">
                                    <i class="fa-regular fa-eye"></i>
                                    <span><?= $result['view'] ;?></span>
                                    </div>
                                </div>
                                <div
                                    class=" baca-selengkapnya text-xs text-black md:text-sm hover:cursor-pointer opacity-70 hover:opacity-100 hover:bg-primary  transition duration-200 py-1 pl-3 pr-1  rounded-full bg-gray-100">
                                    <a href="<?= base_url(); ?>berita/baca/<?= $result['id']; ?>?ref=berita"
                                        class="text-xxs flex items-center">
                                        Baca Selengkapnya
                                        <img src="<?= base_url(); ?>public/assets/images/arrow-read.svg"
                                            class="w-4 ml-2 -rotate-90" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="pagination-berita w-full flex justify-center text-">
            <?= $links; ?>
        </div>
    </section>
    <aside class="md:max-w-[250px] pt-10 px-2 md:pl-0 md:pr-5">
        <div class="populer bg-white rounded-xl w-full min-h-80 shadow-md overflow-hidden ">
            <h2 class="bg-gradient-to-r from-purple-500 to-primary px-5 py-2 font-medium text-lg text-white">Populer</h2>
            <ul class="text-xs text-gray-600">
                <li class="py-2 px-3"><a href="" class="w-full inline-block text-wrap text-justify">Berlangsung khidmat, SMPQ Al-Muanawiyah laksanakan upacara bendera peringati hari sumpah pemuda</a></li>
                <li class="py-2 px-3"><a href="" class="w-full inline-block text-wrap text-justify">Berlangsung khidmat, SMPQ Al-Muanawiyah laksanakan upacara bendera peringati hari sumpah pemuda</a></li>
                <li class="py-2 px-3"><a href="" class="w-full inline-block text-wrap text-justify">Berlangsung khidmat, SMPQ Al-Muanawiyah laksanakan upacara bendera peringati hari sumpah pemuda</a></li>
                <li class="py-2 px-3"><a href="" class="w-full inline-block text-wrap text-justify">Berlangsung khidmat, SMPQ Al-Muanawiyah laksanakan upacara bendera peringati hari sumpah pemuda</a></li>
                <li class="py-2 px-3"><a href="" class="w-full inline-block text-wrap text-justify">Berlangsung khidmat, SMPQ Al-Muanawiyah laksanakan upacara bendera peringati hari sumpah pemuda</a></li>
                <li class="py-2 px-3"><a href="" class="w-full inline-block text-wrap text-justify">Berlangsung khidmat, SMPQ Al-Muanawiyah laksanakan upacara bendera peringati hari sumpah pemuda</a></li>
            </ul>
        </div>
    </aside>
</div>