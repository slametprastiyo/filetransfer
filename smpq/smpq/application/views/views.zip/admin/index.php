<section class="mt-20">

    <ul>
        <li>
            <a href="<?= base_url() ;?>admin/banner">banner</a>
        </li>
        <li>
            <a href="<?= base_url() ;?>admin/news">news</a>
        </li>
        <li>
            <a href="<?= base_url() ;?>admin/galeri">galeri</a>
        </li>
    </ul>
    <?php 
    if($this->session->flashdata("success")){
        echo '<script>Swal.fire("Success", "'. $this->session->flashdata("success") .'", "success")</script>';
    }
    ;?>
</section>