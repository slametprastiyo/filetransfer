<script src="<?= base_url(); ?>public/assets/js/admin-script.js"></script>
</body>

</html>