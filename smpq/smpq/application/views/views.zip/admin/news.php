<section class="mt-20">
    
<h1 class="text-blue-500">Admin / Berita</h1>
<button class="px-3 py-1 border border-primary" id="tambah-berita-btn">+</button>


<div class="admin berita-container h-fit w-full p-5 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
    <?php foreach($news as $n) :?>
        <div
        class="berita-card relative  rounded-lg bg-white w-full flex font-serif p-2 border-b-2 border-primary" data-gambar="3.png" data-id="<?= $n['id'] ;?>" data-name="<?= $n['title'] ;?>">

        <img class="gambar-berita h-20 aspect-square rounded-md bg-grey object-cover object-center" src="<?= base_url("public/assets/images/");?><?= $n['hd'];?>" >
        
        
        <div class="detail  pl-2 w-full flex flex-col justify-between">
            <div class="main flex flex-col">
                <div class="berita-judul font-bold leading-4"><?= $n['title'] ;?></div>
                <!-- <p class="berita-short text-sm max-h-52 overflow-hidden">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia vero repellat doloremque debitis blandriatur sit?</p> -->
            </div>
            <div class="footer flex justify-between font-sans items-center">
                <div class="tanggal text-xs">01/09/2024</div>
            </div>
            <div class="menu absolute flex flex-col h-full justify-around items-end font-quicksand-regular text-sm">
                <a href="<?= base_url("") ;?>admin/news_edit/<?= $n['id'] ;?>" class="edit bg-primary p-1 px-2 relative right-5 text-right cursor-pointer w-fit rounded-lg z-50 pointer-events-auto">Edit</a>
                <button class="delete bg-primary p-1 px-2 relative right-5 text-right cursor-pointer w-fit rounded-lg z-50 pointer-events-auto">Hapus</>
            </div>
        </div>
    </div>
        <?php endforeach;?>
</div>

    <form action="<?= base_url("admin/news_upload") ;?>" id="tambah-berita" method="POST" class="hidden md:w-3/4 h-full p-5 fixed top-10 bg-white shadow-lg rounded-lg w-full h-full top-0 overflow-y-scroll pb-10" enctype="multipart/form-data">
           
           <div
               class="close-btn absolute right-2 top- text-red-500 w-6 rounded-full aspect-square flex justify-center items-center hover:cursor-pointer scale-125">
               x</div>
           <h2 class="font-bold mb-5 text-center">Tulis Berita</h2>
           <div class="mb-4">
               <label for="judul" class="block text-sm font-medium text-gray-700">Judul</label>
               <input type="text" required id="judul" name="judul"
                   class="mt-1 p-2 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
           </div>
           <div class="mb-4">
               <label for="isi" class="block text-sm font-medium text-gray-700">Isi</label>
               <textarea id="isi" required name="isi"
                   class="mt-1 p-2 block min-h-40 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"></textarea>
           </div>
           <img src="" alt="" class="preview max-w-80 mx-auto hidden">

           <div class="mb-4">
               <label for="file" class="block text-sm font-medium text-gray-700">Upload Gambar</label>
               <input type="file" id="file" required name="userfile" accept=".jpg, .png, .jpeg"
                   class="mt-1 p-2 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
           </div>
           <div>
               <button type="submit"
                   class="w-full bg-blue-500 text-white py-2 px-4 rounded-md shadow-sm hover:bg-blue-700 focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">Simpan</button>
           </div>
       </form>
</section>
<?php 
    if($this->session->flashdata("error")){
        echo '<script>Swal.fire("Error", "'. $this->session->flashdata("error") .'", "error")</script>';
    }
    ;?>

<?php 
    if($this->session->flashdata("success")){
        echo '<script>Swal.fire("Success", "Data telah ditambahkan", "success")</script>';
    }
    ;?>
 