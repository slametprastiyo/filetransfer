    <section class="p-5 mt-20">

        <h1 class="text-red-500">Admin / Banner</h1>
        <button class="px-3 py-1 border border-primary" id="tambah-banner-btn">+</button>
        <div class="banner-container w-full max-w-96 mx-auto">
            <?php foreach ($banners as $banner): ?>
                <div
                    class=" banner-card relative rounded-2xl px-5 py-2 my-1 h-40 bg-cover bg-center w-full bg-[url('<?= base_url("public/assets/images/") . $banner['hd']; ?>')]" data-id="<?= $banner['id'] ;?>" data-name="<?= $banner['name'] ;?>">
                    <img src="<?= base_url("public/assets/images/") . $banner['thumb']; ?>"
                        class="w-full h-full object-cover object-center rounded-lg shadow-lg" alt="">
                        <div class="menu h-fit absolute top-1/2 left-0 opacity-0">
                            <button class="block  delete w-8 h-8 bg-[url('../images/trash.png')] bg-center bg-no-repeat bg-cover rounded-lg"></button>
                        </div>
                        <div class="priority absolute -right-2 top-1/2 h-24 flex flex-col justify-around">
                            <div class="up bg-primary text-white hover:cursor-pointer bg-[url('../images/arrow-bg-primary.png')] h-10 w-6 bg-center bg-no-repeat bg-cover rounded-xl opacity-75 hover:opacity-100 hover:scale-105"></div>
                            <div class="down bg-primary text-white hover:cursor-pointer bg-[url('../images/arrow-bg-primary.png')] h-10 w-6 bg-center bg-no-repeat bg-cover rounded-xl opacity-75 hover:opacity-100 hover:scale-105 rotate-180"></div>
                        </div>
                </div>
            <?php endforeach; ?>
        </div>
    
    
        <form action="<?= base_url("admin/banner_upload") ;?>" id="tambah-banner" method="POST" class="hidden p-5 absolute top-10 bg-white shadow-lg rounded-lg" enctype="multipart/form-data">
       
            <div
                class="close-btn absolute right-2 top- text-red-500 w-6 rounded-full aspect-square flex justify-center items-center hover:cursor-pointer scale-125">
                x</div>
            <h2 class="font-bold mb-5 text-center">Tambah Banner</h2>
            <img src="" alt="" class="preview hidden max-w-80 block mx-auto">
            <div class="mb-4">
                <label for="name" class="block text-sm font-medium text-gray-700">Nama / keterangan</label>
                <input type="text" id="name" name="name"
                    class="mt-1 p-2 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div class="mb-4">
                <label for="file" class="block text-sm font-medium text-gray-700">Upload Gambar</label>
                <input type="file" id="file" name="userfile"
                    class="mt-1 p-2 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
            </div>
            <div>
                <button type="submit"
                    class="w-full bg-blue-500 text-white py-2 px-4 rounded-md shadow-sm hover:bg-blue-700 focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">Simpan</button>
            </div>
        </form>

    </section>    

    <?php 
    if($this->session->flashdata("error")){
        echo '<script>Swal.fire("Error", "'. $this->session->flashdata("error") .'", "error")</script>';
    }
    ;?>
 
    <?php 
    if($this->session->flashdata("success")){
        echo '<script>Swal.fire("Success", "Data telah ditambahkan", "success")</script>';
    }
    ;?>
 