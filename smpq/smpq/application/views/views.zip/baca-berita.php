<header class="bg-primary fixed w-full z-50 p-2">
    <button class=" text-black rounded-lg">
        <?php if($ref == "") :?>
        <a href="<?= base_url();?>#berita">
            <?php elseif($ref == "berita") :?>
                <a href="<?= base_url();?>berita">
                            <?php endif;?>
            <img src="<?= base_url() ;?>public/assets/images/arrow-left-circle.svg" class="w-8 h-8" alt="">
        </a>
    </button>
</header>
<section id="baca-berita" class="baca-berita p-5 pt-16 " data-thumb="<?= $berita['thumb'] ;?>" data-hd="<?= $berita['hd'] ;?>" data-id="<?= $berita['id'] ;?>">
    <div class="baca-berita-container bg-white  px-5 py-3 lg:px-10 lg:py-5 rounded-lg shadow-lg">
        <div class="header w-full mb-5">
            <h1 class="font-bold text-2xl capitalize"><?= $berita['title'] ;?></h1>
            <span class="text-sm opacity-50 mb-5"><?= $berita['created_at'] ;?></span>
            <ul class="sharer"> 
                <li>
                    <a href="https://api.whatsapp.com/send?text=*<?= $berita['title'] ;?>*%0ahttps://smpqalmuanawiyah.sch.id/berita/baca/<?= $berita['id'];?>" target="_blank" class="inline-block bg-green-600 px-2 py-1 rounded-full">
                        <i class="text-xl fa-brands fa-whatsapp text-white"></i>
                    </a>
                </li>
            </ul>
               

        </div>
        <div class="main clearfix">
                <img id="baca-berita-img" src="<?= base_url() ;?>public/assets/images/<?= $berita['hd'] ;?>" alt="" class="relative w-full aspect-video object-cover object-center hd top-0 object-cover object-center md:w-1/2 md:h-auto md:float-right md:ml-5 mb-5 rounded-2xl">
              <?= $berita['isi'] ;?>
    </div>
    </div>
    
</section>


