<header class="min-h-[500px] flex justify-center items-center bg-[url('../images/profil-hero-bg.jpg')] bg-no-repeat bg-cover  pt-12">
    <h1 class="uppercase text-white font-bold text-5xl">profil</h1>
</header>
<div class="profil-container w-full flex flex-col md:flex-row p-10 lg:max-w-5xl mx-auto">
    <aside class="w-full md:w-fit md:h-screen relative w-24 mx-auto">
        <div class="aside-container h-fit  bg-white shadow-lg mb-10 py-5 rounded-xl border-2 border-gray-100">
            <ul>
                <li ><a href="#visi-misi" class="hover:bg-gray-100 block p-3 text-nowrap px-5">visi & misi</a></li>
                <li ><a href="#struktur-organisasi" class="hover:bg-gray-100 block p-3 text-nowrap px-5">struktur organisasi</a></li>
            </ul>
        </div>
    </aside>
    <main class=" w-full relative ">
        <section id="visi-misi" class=" relative visi-misi ml-10 md:ml-32 mb-20">
            <h2 class="mb-5  font-bold text-3xl visi relative">VISI</h2>
            <ul class=" mb-10">
                <li class="text-gray-700">
                    <p>Terwujudnya peserta didik yang berjiwa qurani dan unggul dalam IPTEK</p>
                </li>
            </ul>
            <h2 class="mb-5  font-bold text-3xl relative misi">MISI</h2>
            <ul class="misi">
                <li class="mb-3 relative leading-10 text-gray-700">
                    <p>Terwujudnya peserta didik yang berjiwa qurani dan unggul dalam IPTEK</p>
                </li>
                <li class="mb-3 relative leading-10 text-gray-700">
                    <p>Terwujudnya peserta didik yang berjiwa qurani dan unggul dalam IPTEK Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam velit blanditiis totam. Iste praesentium blanditiis possimus. Placeat esse tempore deleniti molestias porro ipsam voluptatum quam expedita sequi, non laudantium sint magnam dolores temporibus voluptatem amet! Quos ratione, similique sunt recusandae quis, sequi dolorem quam deserunt perferendis saepe, tempora temporibus provident?</p>
                </li>
                <li class="mb-3 relative leading-10 text-gray-700">
                    <p>Terwujudnya peserta didik yang berjiwa qurani dan unggul dalam IPTEK</p>
                </li>
                <li class="mb-3 relative leading-10 text-gray-700">
                    <p>Terwujudnya peserta didik yang berjiwa qurani dan unggul dalam IPTEK</p>
                </li>
                <li class="mb-3 relative leading-10 text-gray-700">
                    <p>Terwujudnya peserta didik yang berjiwa qurani dan unggul dalam IPTEK</p>
                </li>
                <li class="mb-3 relative leading-10 text-gray-700">
                    <p>Terwujudnya peserta didik yang berjiwa qurani dan unggul dalam IPTEK</p>
                </li>
                <li class="mb-3 relative leading-10 text-gray-700">
                    <p>Terwujudnya peserta didik yang berjiwa qurani dan unggul dalam IPTEK</p>
                </li>
            </ul>

        </section>
        <section id="struktur-organisasi" class=" struktur-organisasi ml-10 md:ml-32 ">
            <img src="<?= base_url() ;?>public/assets/images/struktur-organisasi.jpg" alt="">
        </section>
    </main>
</div>