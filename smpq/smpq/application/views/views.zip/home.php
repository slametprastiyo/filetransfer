<section
    class="hero relative w-full mx-auto aspect-4/3 lg:min-h-screen lg:aspect-auto  bg-no-repeat bg-cover border-y overflow-hidden">
    <div
        class=" identity absolute top-0 left-0 w-full h-full z-20 text-white flex flex-col justify-center md:pb-0  items-center px-20 pt-20">
        <!-- <img src="<?= base_url(); ?>public/assets/images/logo-putih.png" alt="logo smp quran Almuanawiyah" class="w-20 opacity-0 md:opacity-100"> -->
        <h1 class="text-start my-4 text-2xl md:text-3xl lg:text-7xl font-semibold">SMP Quran <br><span
                class="text-3xl md:text-5xl lg:text-9xl lato-bold">Al-Muanawiyah</span></h1>
    </div>
    <?php foreach ($banners as $banner): ?>
        <div class="mySlides fade h-full lg:h-screen relative" data-image="<?= $banner['hd']; ?>">
            <img src="<?= base_url() ?>public/assets/images/<?= $banner['thumb']; ?>" class="w-full h-full object-cover"
                alt="">
            <div class="overlay w-full h-full bg-black absolute top-0 left-0 flex justify-center items-center">
                <img src="<?= base_url() ?>public/assets/images/loader.svg" class="w-5 h-5 rounded-lg"
                    alt="<?= $banner['name']; ?>">
            </div>

            <img src="" class="hd absolute top-0 left-0 w-full h-full object-cover hidden" alt="">
        </div>
    <?php endforeach; ?>

    <a
        class="prev absolute top-1/2 w-auto p-4 mt-5 text-white text font-bold text-lg select-none hover:bg-black/50 hover:cursor-pointer z-30">❮</a>
    <a
        class="next absolute top-1/2 w-auto p-4 mt-5 text-white text font-bold text-lg select-none right-0 hover:bg-black/50 hover:cursor-pointer z-30">❯</a>
</section>

<section class="fasilitas min-h-screen pt-32 relative">
    <div class="fasilitas-header bg-gradient-to-t from-teal-700 to-transparent ">
        <img src="<?= base_url() ?>public/assets/images/fasilitas-header.png" alt="" class="w-3/4 max-w-2xl mx-auto">
    </div>
    <div class="fasilitas-container bg-teal-700 ">
        <div class="fasilitas-main  relative  flex flex-col md:flex-row pt-20 px-5">
            <div class="fasilitas-detail flex md:flex-col md:w-1/2 md:justify-center pb-20 md:pb-0">
                <ul class=" mx-2 w-1/2 md:w-full text-center text-lg md:text-lg lg:text-2xl font-semibold text-white">
                    <li class="w-fit mx-auto lg:leading-10">Area Full WiFi</li>
                    <li class="w-fit mx-auto lg:leading-10">LCD Proyektor / <br>Televisi Android</br></li>
                    <li class="w-fit mx-auto lg:leading-10">Pendingin Ruangan</li>
                    <li class="w-fit mx-auto lg:leading-10">Perpustakaan</li>
                    <li class="w-fit mx-auto lg:leading-10">Mini Laboratorium</li>
                    <li class="w-fit mx-auto lg:leading-10">Lab. Komputer</li>
                </ul>
                <ul class=" mx-2 w-1/2 md:w-full text-center text-lg md:text-lg lg:text-2xl font-semibold text-white">
                    <li class="w-fit mx-auto lg:leading-10">Studio Multimedia</li>
                    <li class="w-fit mx-auto lg:leading-10">Kantin</li>
                    <li class="w-fit mx-auto lg:leading-10">Ruang UKS</li>
                    <li class="w-fit mx-auto lg:leading-10">Musholla</li>
                    <li class="w-fit mx-auto lg:leading-10">Aula (kapasitas 120 siswa)</li>
                    <li class="w-fit mx-auto lg:leading-10">Ruang Guru</li>
                    <li class="w-fit mx-auto lg:leading-10">Ruang TU</li>
                </ul>
            </div>
            <div class="fasilitas-img md:w-1/2">
                <img src="<?= base_url() ?>public/assets/images/fasilitas.png" alt=""
                    class="w-full max-w-xl mx-auto pb-20">
            </div>

        </div>
        <div class="z-40 enrol w-32 h-10 mx-auto  relative flex justify-center items-center hover:cursor-pointer scale-110">
            <div class="w-full h-full bg-white/50 absolute rounded-full  animate-ping"></div>
            <div class="w-full h-full bg-primary absolute rounded-full border-2 border-white "></div>
            <span class="absolute text-white">Pendaftaran</span>
        </div>
    </div>

</section>

<section
    class="sambutan  bg-gradient-to-b from-teal-700 via-transparent to-gray-100 py-20 px-5 lg:px-10 lg:px-40 relative">

    <div class="sambutan-container bg-no-repeat bg-left flex flex-col md:flex-row items-center lg:justify-around bg-white shadow-lg rounded-3xl p-5 wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <div class="foto  w-full text-center p-5 md:flex-1">
            <img src="<?= base_url() ?>public/assets/images/ks2.jpeg" alt=""
                class="w-1/2 lg:w-9/12 mx-auto  my-2 object-cover rounded-full">
            <!-- <img src="public/assets/images/headmaster.png" alt=""
                class="w-full max-w-48 aspect-square mx-auto  my-2">
            <p class="font-regular"><span class="text-xl font-semibold">A. Mu'ammar Sholahuddin, S. Pd</span><br>
                Pendiri Pesantren Al-Muanawiyah</p> -->
        </div>
        <div class="teks mb-5 md:w-3/5   text-gray-700 text-[.9rem] md:flex-2">
            <span class="mb-10 text-l sub-title block text-center">Sambutan Kepala SMP Quran Al-Muanawiyah</span>
            <div class="teks-container overflow-y-scroll w-full max-h-72  pr-6 mt-10">
                <h2 class=" font-medium mb-1 opacity-60">Assalamu'alaikum Wr.Wb.</h2>
                <p class="mb-2 indent-4 text-justify opacity-60">
                    Puji syukur kita panjatkan kehadirat Allah SWT atas segala rahmat dan hidayah-Nya, sehingga kita
                    semua
                    dapat beraktivitas dengan baik dan dalam keadaan sehat walafiat.
                </p>
                <p class="mb-2 indent-4 text-justify opacity-60">
                    SMP Qur'an Al-Muanawiyah terus berinovasi dalam metode pengajaran, meningkatkan kualitas tenaga
                    pendidik, serta memperkaya fasilitas belajar guna merealisasikan visi kami yaitu terwujudnya peserta
                    didik yang berjiwa qur'ani dan unggul dalam IPTEK.
                </p>
                <p class="mb-2 indent-4 text-justify opacity-60">
                    Kami sangat mengapresiasi dukungan dari orang tua santri dan seluruh stakeholder pendidikan yang
                    telah turut serta membangun lingkungan pendidikan yang kondusif dan harmonis. Kebersamaan dan
                    kolaborasi
                    ini merupakan kunci kesuksesan dalam mencetak generasi penerus bangsa yang handal.
                </p>
                <p class="mb-2 indent-4 text-justify opacity-60">
                    Akhir kata, mari kita bersama-sama melangkah maju untuk mewujudkan cita-cita pendidikan yang luhur.
                    Semoga Allah SWT senantiasa meridhai setiap langkah kita. <br>
                    Wassalamu'alaikum warahmatullahi wabarakatuh.
                </p>
                <p class="font-regular mt-5"><span class="text-xl font-semibold">Lia Amirotus Zakiyah, S.Pd</span><br>
                    <span class="opacity-60">
                        Kepala SMPQ Al-Muanawiyah
                    </span>
                </p>
            </div>
        </div>
    </div>
</section>


<section class="berita min-h-screen px-1 md:px-10  py-20 bg-gray-100" id="berita">
    <div class="text-center capitalize z-10 relative text-black mb-20 block w-fit mx-auto p-5 bg-[url('../images/rect.png')] bg-no-repeat bg-contain bg-left wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <h2 class=" bg-gray-100 font-semibold text-xl">Berita Terbaru</h2>
    </div>
    <div class="berita-outer-container flex flex-col md:flex-row wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <div class="berita-container h-fit w-full grid gap-3 md:grid-cols-2 lg:grid-cols-3">

            <?php if ($news != null): ?>
                <?php foreach ($news as $n): ?>
                    <div class="berita-card relative bg-cover shadow-md rounded-2xl bg-white w-full flex p-3  transition-all duration-300 ease-out"
                        data-thumb="<?= $n['thumb']; ?>" data-hd="<?= $n['hd']; ?>" id="<?= $n['id']; ?>">
                        <div class="news-image-container relative w-40 aspect-square overflow-hidden rounded-lg">
                            <img class="gambar-berita  object-cover object-center hd h-full w-full rounded-md  absolute hidden">
                            <img class="gambar-berita  object-cover object-center thumb h-40 w-full rounded-md absolute ">
                            <div class="overlay w-full h-full bg-black absolute top-0 left-0 flex justify-center items-center">
                                <img src="<?= base_url() ?>public/assets/images/loader.svg" class="w-5 h-5 rounded-lg" alt="">
                            </div>
                            <div class="kategori-berita absolute left-0 top-0 bg-primary py-1 px-2 rounded-br-lg text-xxs">
                                Kegiatan
                            </div>
                        </div>
                        <div class="detail  pl-2 w-full flex flex-col justify-between">
                            <div class="main flex flex-col">
                                <div class="berita-judul font-semibold leading-4 text-wrap "><?= $n['title']; ?></div>
                                <!-- <p class="berita-short text-sm max-h-52 overflow-hidden">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia vero repellat doloremque debitis blandriatur sit?</p> -->
                            </div>
                            <div class="footer flex justify-between items-center">
                                <div class="detail-berita  text-xxs text-gray-600">
                                    <div class="tanggal   inline-block">01/09/2024</div>
                                    <div class="view  inline-block ml-2">
                                        <i class="fa-regular fa-eye"></i>
                                        <span><?= $n['view']; ?></span>
                                    </div>
                                </div>
                                <div
                                    class=" baca-selengkapnya text-xs text-black md:text-sm hover:cursor-pointer opacity-70 hover:opacity-100 hover:bg-primary  transition duration-200 py-1 pl-3 pr-1  rounded-full bg-gray-100">
                                    <a href="<?= base_url(); ?>berita/baca/<?= $n['id']; ?>?ref="
                                        class="text-xxs flex items-center">
                                        Baca Selengkapnya
                                        <img src="<?= base_url(); ?>public/assets/images/arrow-read.svg"
                                            class="w-4 ml-2 -rotate-90" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>




        </div>
        <!-- <div
            class="berita-populer max-w-full md:max-w-[450px] my-10 shadow-md rounded-xl overflow-hidden lg:w-96 md:m-0 md:h-fit md:ml-5 relative bg-white">
            <h3 class="block bg-black text-white p-3 text-sm">Populer</h3>
            <div class="berita-populer-container font-serif">
                <a href="#"
                    class="relative transition-all hover:left-2 block py-1 border-b border-primary text-black/75 hover:text-black  px-3  duration-500 text-xs">
                    Proin faucibus eu massa a tincidunt. Duis et ex non mi semper vehicula.
                </a>
                <a href="#"
                    class="relative transition-all hover:left-2 block py-1 border-b border-primary text-black/75 hover:text-black  px-3  duration-500 text-xs">Lorem
                    ipsum dolor sit amet
                    consectetur adipisicing.</a>
                <a href="#"
                    class="relative transition-all hover:left-2 block py-1 border-b border-primary text-black/75 hover:text-black  px-3  duration-500 text-xs">Lorem
                    ipsum dolor sit amet
                    consectetur adipisicing elit. Consectetur illo, saepe</a>
                <a href="#"
                    class="relative transition-all hover:left-2 block py-1 border-b border-primary text-black/75 hover:text-black  px-3  duration-500 text-xs">Lorem
                    ipsum dolor sit amet
                    consectetur.</a>
                <a href="#"
                    class="relative transition-all hover:left-2 block py-1 border-b border-primary text-black/75 hover:text-black  px-3  duration-500 text-xs">Lorem
                    ipsum dolor sit amet
                    consectetur adipisicing elit. Consectetur illo, saepe</a>
            </div>
        </div> -->
    </div>
    <div class="load-more text-center w-fit mx-auto hover:cursor-pointer text-black relative z-10 bg-white py-2 px-4 font-quicksand-medium transition-all duration-200 hover:bg-black hover:text-white rounded-full mt-10 wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <a href="<?= base_url(); ?>berita">Selengkapnya ...</a>
    </div>
</section>
<section class="ekstra swiper-container min-h-screen relative py-20 " id="ekstra">
    <div class="text-center capitalize z-10 relative  mb-20 block w-fit mx-auto p-5 bg-[url('../images/rect.png')] bg-no-repeat bg-contain bg-left wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <h2 class=" bg-white font-semibold text-xl ">Ekstrakurikuler</h2>
    </div>
    <div class="swiper ekstraSwiper w-full h-80 max-w-[1000px] mx-auto wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <div class="swiper-wrapper">
            <div
                class="swiper-slide rounded-lg overflow-hidden text-center text-lg bg-white flex justify-center items-center max-w-80">
                <img src="<?= base_url(); ?>public/assets/images/pramuka.jpeg" class="block w-full h-full  object-cover"
                    alt="">
                <div
                    class="absolute bottom-0 h-20 bg-gradient-to-t from-black via-black/80 to-black/0 flex justify-start z-50 w-full pt-4">
                    <span
                        class=" block  text-center hover:bg-white hover:text-black text-white border px-2 border-white h-fit mx-auto bg-white/10 rounded-md cursor-pointer">
                        <a href="<?= base_url("program/#tahfidz"); ?>">Pramuka</a>
                    </span>
                </div>
            </div>
            <div
                class="swiper-slide rounded-lg overflow-hidden text-center text-lg bg-white flex justify-center items-center max-w-80">
                <img src="<?= base_url(); ?>public/assets/images/olimpiade-sains.jpeg"
                    class="block w-full h-full  object-cover" alt="">
                <div
                    class="absolute bottom-0 h-20 bg-gradient-to-t from-black via-black/80 to-black/0 flex justify-start z-50 w-full pt-4">
                    <span
                        class=" block  text-center hover:bg-white hover:text-black text-white border px-2 border-white h-fit mx-auto bg-white/10 rounded-md cursor-pointer">
                        <a href="<?= base_url("program/#tahfidz"); ?>">Olimpiade SAINS</a>
                    </span>
                </div>
            </div>
            <div
                class="swiper-slide rounded-lg overflow-hidden text-center text-lg bg-white flex justify-center items-center max-w-80">
                <img src="<?= base_url(); ?>public/assets/images/1.jpg" class="block w-full h-full  object-cover"
                    alt="">
                <div
                    class="absolute bottom-0 h-20 bg-gradient-to-t from-black via-black/80 to-black/0 flex justify-start z-50 w-full pt-4">
                    <span
                        class=" block  text-center hover:bg-white hover:text-black text-white border px-2 border-white h-fit mx-auto bg-white/10 rounded-md cursor-pointer">
                        <a href="<?= base_url("program/#tahfidz"); ?>">Olimpiade Math</a>
                    </span>
                </div>
            </div>

            <div
                class="swiper-slide rounded-lg overflow-hidden text-center text-lg bg-white flex justify-center items-center max-w-80">
                <img src="<?= base_url(); ?>public/assets/images/kaligrafi.jpeg"
                    class="block w-full h-full  object-cover" alt="">
                <div
                    class="absolute bottom-0 h-20 bg-gradient-to-t from-black via-black/80 to-black/0 flex justify-start z-50 w-full pt-4">
                    <span
                        class=" block  text-center hover:bg-white hover:text-black text-white border px-2 border-white h-fit mx-auto bg-white/10 rounded-md cursor-pointer">
                        <a href="<?= base_url("program/#tahfidz"); ?>">Kaligrafi</a>
                    </span>
                </div>
            </div>

            <div
                class="swiper-slide rounded-lg overflow-hidden text-center text-lg bg-white flex justify-center items-center max-w-80">
                <img src="<?= base_url(); ?>public/assets/images/seni-lukis.jpeg"
                    class="block w-full h-full  object-cover" alt="">
                <div
                    class="absolute bottom-0 h-20 bg-gradient-to-t from-black via-black/80 to-black/0 flex justify-start z-50 w-full pt-4">
                    <span
                        class=" block  text-center hover:bg-white hover:text-black text-white border px-2 border-white h-fit mx-auto bg-white/10 rounded-md cursor-pointer">
                        <a href="<?= base_url("program/#tahfidz"); ?>">Seni Lukis</a>
                    </span>
                </div>
            </div>
            <div
                class="swiper-slide rounded-lg overflow-hidden text-center text-lg bg-white flex justify-center items-center max-w-80">
                <img src="<?= base_url(); ?>public/assets/images/banjari.png" class="block w-full h-full  object-cover"
                    alt="">
                <div
                    class="absolute bottom-0 h-20 bg-gradient-to-t from-black via-black/80 to-black/0 flex justify-start z-50 w-full pt-4">
                    <span
                        class=" block  text-center hover:bg-white hover:text-black text-white border px-2 border-white h-fit mx-auto bg-white/10 rounded-md cursor-pointer">
                        <a href="<?= base_url("program/#tahfidz"); ?>">Banjari</a>
                    </span>
                </div>
            </div>

            <div
                class="swiper-slide rounded-lg overflow-hidden text-center text-lg bg-white flex justify-center items-center max-w-80">
                <img src="<?= base_url(); ?>public/assets/images/multimedia.jpeg"
                    class="block w-full h-full  object-cover" alt="">
                <div
                    class="absolute bottom-0 h-20 bg-gradient-to-t from-black via-black/80 to-black/0 flex justify-start z-50 w-full pt-4">
                    <span
                        class=" block  text-center hover:bg-white hover:text-black text-white border px-2 border-white h-fit mx-auto bg-white/10 rounded-md cursor-pointer">
                        <a href="<?= base_url("program/#tahfidz"); ?>">Multimedia</a>
                    </span>
                </div>
            </div>
            <div
                class="swiper-slide rounded-lg overflow-hidden text-center text-lg bg-white flex justify-center items-center max-w-80">
                <img src="<?= base_url(); ?>public/assets/images/desain-grafis.jpeg"
                    class="block w-full h-full  object-cover" alt="">
                <div
                    class="absolute bottom-0 h-20 bg-gradient-to-t from-black via-black/80 to-black/0 flex justify-start z-50 w-full pt-4">
                    <span
                        class=" block  text-center hover:bg-white hover:text-black text-white border px-2 border-white h-fit mx-auto bg-white/10 rounded-md cursor-pointer">
                        <a href="<?= base_url("program/#tahfidz"); ?>">Desain Grafis</a>
                    </span>
                </div>
            </div>






        </div>

        <div class="swiper-pagination"></div>
    </div>
</section>

<section class="galery min-h-screen  py-20  relative" id="galeri">
    <!-- <div class="absolute top-0 bottom-0 right-0 left-0 bg-black opacity-90 z-0"></div> -->
    <div class="text-center capitalize z-10 relative text-black mb-20 block w-fit mx-auto p-5 bg-[url('../images/rect.png')] bg-no-repeat bg-contain bg-left wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <h2 class=" bg-white  lato-bold text-xl  pr-2">Galeri</h2>
    </div>
    <div class="galery-container p-5 rounded-3xl w-full max-w-7xl mx-auto z-10 relative mb-5  bg-gray-100 wow animate__animated animate__fadeInUp grid-flow-dense"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <?php foreach ($galeries as $g): ?>

            <div class="<?php echo $g['dimension']; ?> rounded-md galery-element relative overflow-hidden w-full h-full"
                data-id="<?= $g['id']; ?>" data-hd="<?= $g['hd']; ?>" data-thumb="<?= $g['thumb']; ?>"
                data-caption="<?= $g['caption']; ?>" data-dimension="<?php echo $g['dimension']; ?>">
                <div class="menu h-fit absolute top-1/2 left-2 transition-all duration-300 opacity-0">
                    <button
                        class="block  delete w-8 h-8 bg-[url('../images/trash.png')] bg-center bg-no-repeat bg-cover rounded-lg"></button>
                </div>
                <img src="" class=" hd w-full h-full object-cover object-center hidden">
                <img src="" class=" thumb w-full h-full object-cover object-center hidden">
                <div class="overlay w-full h-full bg-black absolute top-0 left-0 flex justify-center items-center">
                    <img src="<?= base_url() ?>public/assets/images/loader.svg" class="w-5 h-5 rounded-lg" alt="">
                </div>
            </div>

        <?php endforeach; ?>

    </div>
    <div class="load-more galeri text-center w-fit mx-auto hover:cursor-pointer text-black relative z-10 bg-gray-100 py-2 px-4 font-quicksand-medium transition-all duration-200 hover:bg-black hover:text-white rounded-full mt-10 wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">Tampilkan
        lebih banyak ...</div>
</section>

<section class="youtube py-20 bg-gray-100">
    <div class="text-center capitalize z-10 relative text-black mb-20 block w-fit mx-auto p-5 bg-[url('../images/rect.png')] bg-no-repeat bg-contain bg-left wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <h2 class=" bg-gray-100 font-semibold text-xl">Youtube SMPQ Almuanawiyah</h2>
    </div>
    <div class="w-full youtube-container grid px-10 md:grid-cols-2 lg:grid-cols-3 gap-5 wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <iframe class="youtube w-full h-60 md:h-40 lg:h-48 rounded-lg overflow-hidden" src=""
            data-src="https://www.youtube.com/embed/1JrlRcx9I_w?si=Tc5KcPw6Yv2uO0g-" title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        <iframe class="youtube w-full h-60 md:h-40 lg:h-48 rounded-lg overflow-hidden" src=""
            data-src="https://www.youtube.com/embed/Xc9q3ByeWZs?si=2NMrh7IYEGBmWlY7" title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        <iframe class="youtube w-full h-60 md:h-40 lg:h-48 rounded-lg overflow-hidden" src=""
            data-src="https://www.youtube.com/embed/D8-R2iIf1UI?si=y_R42yHMe_1HgZkv" title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    </div>
    <div class="load-more text-center w-fit mx-auto hover:cursor-pointer text-white relative z-10 bg-black py-2 px-4 font-quicksand-medium transition-all duration-200 hover:bg-white hover:text-black rounded-lg mt-5 wow animate__animated animate__fadeInUp"
        data-wow-duration=".5s" data-wow-delay=".25s" data-wow-offset="100">
        <a href="https://www.youtube.com/@smpqalmuanawiyah" target="_blank">Selengkapnya</a>
    </div>
</section>

</div>
</section>