<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    .grid{
      display: column;
      columns: 4;
      background-color: gray;
      padding: 1rem;
      gap:1rem;
    }
    .grid-item{
      margin-bottom: 1rem;
      /* overflow: hidden; */
    }
    img{
      border-radius: 10px;
      width: 100%;
    }
    /* Extra small devices (phones, 600px and down) */
@media only screen and (max-width: 600px) {
  .grid{
    columns:3;
    gap:5px;
  }
  .grid-item{
      margin-bottom: 5px;
      /* overflow: hidden; */
    }
}

/* Small devices (portrait tablets and large phones, 600px and up) */
@media only screen and (min-width: 600px) {
  .grid{
    columns:2;
  }
}

/* Medium devices (landscape tablets, 768px and up) */
/* @media only screen and (min-width: 768px) {...} */

/* Large devices (laptops/desktops, 992px and up) */
/* @media only screen and (min-width: 992px) {...} */

/* Extra large devices (large laptops and desktops, 1200px and up) */
/* @media only screen and (min-width: 1200px) {...} */
  </style>
</head>
<body>
<div class="grid">
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/4.jpg" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/1729658544.png" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/1729658544.png" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/1729658544.png" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/thumb1729865131.jpeg" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/4.jpg" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/1729658544.png" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/1729658544.png" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/1729658544.png" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/thumb1729865131.jpeg" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/4.jpg" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/1729658544.png" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/1729658544.png" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/1729658544.png" alt=""></div>
  <div class="grid-item"><img src="<?= base_url() ;?>public/assets/images/thumb1729865131.jpeg" alt=""></div>
</div>
<button>click me</button>
<script src="<?= base_url(); ?>public/assets/js/masonry.pkgd.min.js"></script>
<script>
  const grid = document.querySelector(".grid");
  const button =document.querySelector("button");
  button.addEventListener("click",()=>{
    const gridItem =document.createElement("div");
    gridItem.classList.add("grid-item");
    const img =document.createElement("img");
    img.src = "http://localhost/smpq/public/assets/images/thumb1729865131.jpeg";

    gridItem.appendChild(img);
    grid.appendChild(gridItem);
  })
</script>
</body>
</html>