<!DOCTYPE html>
<html lang="en" class="">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PPDB SMP Quran Al-Muanawiyah 2025/2026</title>
    <meta name="description"
        content="Website resmi SMP Quran Al-Muanawiyah. Menerima Peserta Didik Baru tahun ajaran 2025/2026">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?= base_url(); ?>public/assets/css/output.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"/>

    <link rel="stylesheet" href="<?= base_url(); ?>public/assets/css/berita.css">
    <link rel="stylesheet" href="<?= base_url(); ?>public/assets/css/swiper-bundle.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>public/assets/css/animate.min.css">
    <script src="<?= base_url(); ?>public/assets/js/wow.min.js"></script>
    <link rel="icon" href="favicon.png" type="image/png">
</head>

<body class="font-quicksand-regular text-black relative max-w-[3000px] relative ">
    <div
        class="hidden hover:cursor-pointer rounded hover:bg-white/70 scroll-to-top w-12 rotate-45 bottom-8 right-8 aspect-square text-white bg-white/20 z-40 fixed flex justify-center items-center shadow-lg">
        <img src="<?= base_url(); ?>public/assets/images/up-arrow.svg"
            class="w-1/2 self-center aspect-square -rotate-45" alt="">
    </div>
    <div
        class="hidden visi-misi w-full h-screen bg-black z-50 bg-opacity-[0.75] fixed overflow-y-scroll backdrop-blur-xl flex justify-center">
        <div class="w-10/12 md:w-3/5 lg:w-6/12  xl:3/12 absolute ">
            <img src="<?= base_url() ?>public/assets/images/visi-misi-bg-transparent.webp" class="w-full" alt="">
            <div
                class="close-btn absolute right-2 top-2 bg-white text-black w-6 rounded-full aspect-square flex justify-center items-center hover:cursor-pointer scale-125">
                x</div>
        </div>
    </div>
    <div
        class="hidden galery-full-view w-full h-screen bg-black z-50 bg-opacity-[0.75] fixed overflow-y-scroll backdrop-blur-xl text-white flex justify-center items-center flex-col">
        <img src="<?= base_url() ?>public/assets/images/1.jpg" alt="">
        <p class="detail text-white mt-3 text-xs font-serif font-thin">Lorem, ipsum dolor sit amet consectetur
            adipisicing elit. Eum, labore!</p>
        <div
            class="close-btn fixed right-2 top-2 bg-white text-black w-6 rounded-full aspect-square flex justify-center items-center hover:cursor-pointer scale-125">
            x</div>
    </div>
    <!-- <divp-[[]] -->
    <header class="fixed w-full z-40 text-white bg-black/0 transition-all duration-200">
        <div class="w-full h-12 bg-white text-black text-xs font-sans px-5 py-2 flex justify-between">
            <div class="left-head inline-flex items-center gap-3">
                <div class="inline-flex items-center gap-1"><span><img
                            src="<?= base_url() ?>public/assets/images/phone.svg" class="w-3" alt=""></span>+62
                    878-5443-6833</div>
                <div class="inline-flex items-center gap-3 relative h-6 w-12 justify-center items-center cursor-pointer enrol">
                    <div class="w-full h-full bg-green-500/70 absolute rounded-lg  animate-ping"></div>
                    <div class="w-full h-full bg-green-500 absolute rounded-lg border-b border-black "></div>
                    <span class="absolute text-white">Enrol</span>
                </div>
            </div>
            <div class="inline-flex items-center gap-3 max-h-10">
                <a href="https://www.instagram.com/almuanawiyah/" target="_blank" class="h-full flex items-center">
                    <img src="<?= base_url() ;?>public/assets/images/instagram-logo.webp" class="h-3/5" alt="">
                </a>
                <a href="https://api.whatsapp.com/send?phone=6285645754384" target="_blank" class="h-full flex items-center">
                    <img src="<?= base_url() ;?>public/assets/images/whatsapp-logo.webp" class="h-4/5" alt="">
                <a href="https://www.youtube.com/@smpqalmuanawiyah" target="_blank" class="h-full flex items-center">
                    <img src="<?= base_url() ;?>public/assets/images/youtube-logo.png" class="h-3/5" alt="">
                </a>
            </div>
        </div>
        <div class="bg-black  w-full px-10 md:px-20 flex justify-between items-center relative header-container font-quicksand-bold">
            <div class="logo-smp py-2">
                <a href="<?= base_url(); ?>">
                    <img src="<?= base_url() ?>public/assets/images/logo-white.svg" alt="" class="w-10">
                </a>
            </div>
            <button type="button" class="md:hidden hamburger absolute right-5">
                <span
                    class="w-[20px] h-[3px] bg-white block my-1 relative transition-all duration-300 ease-in-out origin-top-left"></span>
                <span
                    class="w-[20px] h-[3px] bg-white block my-1 relative transition-all duration-300 ease-in-out origin-top-left"></span>
                <span
                    class="w-[20px] h-[3px] bg-white block my-1 relative transition-all duration-300 ease-in-out origin-bottom-left"></span>
            </button>
            <div class="nav-container flex md:items-center">

                <nav
                    class="hidden md:block absolute bg-white md:bg-transparent md:text-white  text-black top-3/4 right-10 rounded-lg md:static shadow-lg md:shadow-none z-50">
                    <ul class="static md:flex justify-between items-center">
                        <li class=" ">
                            <a href="<?= base_url() ;?>#program"
                                class="rounded-lg block px-3 py-2  hover:bg-gray-100 md:hover:bg-transparent internal-link">Program</a>
                        </li>

                        <li>
                            <div class="relative inline-block text-left menu mx-3 py-2 dropdown-parent">
                                <div>
                                    <button id=""
                                        class=" inline-flex justify-center w-full text-sm font-medium rounded-md py-2">
                                        Profil
                                    </button>
                                </div>
                                <div id=""
                                    class="dropdown-menu hidden z-50  origin-top-right absolute right-0  min-w-fit rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                                    <div class="py-1 " role="menu" aria-orientation="vertical" aria-labelledby="">
                                        <a href="#"
                                            class="whitespace-nowrap internal-link visi-misi-btn block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 "
                                            role="menuitem">Visi & Misi</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class=" ">
                            <a href="<?= base_url() ;?>#galeri"
                                class="block px-3 py-2  hover:bg-gray-100 md:hover:bg-transparent internal-link">Galeri</a>
                        </li>
                    </ul>
                </nav>
                <div class="hidden mx-5 md:block opacity-50">|</div>
                <nav
                    class="admin-nav hidden md:block absolute bg-white md:bg-transparent md:text-white  text-black top-3/4 right-10 rounded-lg md:static shadow-lg md:shadow-none z-50">
                    <ul class="static md:flex justify-between">

                        <li class=" ">
                            <a href="<?= base_url("admin"); ?>"
                                class="rounded-lg block px-3 py-2  hover:bg-gray-100 md:hover:bg-transparent">Admin</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>

    </header>