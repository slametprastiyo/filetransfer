<?php
foreach ($results as $row) {
    echo $row->id; // Display your data
}

echo $links; // Display pagination links
