<div class="swiper mySwiper h-screen w-full mx-auto">
    <div class="swiper-wrapper">
      <div class="swiper-slide text-center text-lg bg-white flex justify-center items-center">Slide 1</div>
      <div class="swiper-slide text-center text-lg bg-white flex justify-center items-center">Slide 2</div>
      <div class="swiper-slide text-center text-lg bg-white flex justify-center items-center">Slide 3</div>
      <div class="swiper-slide text-center text-lg bg-white flex justify-center items-center">Slide 4</div>
      <div class="swiper-slide text-center text-lg bg-white flex justify-center items-center">Slide 5</div>
      <div class="swiper-slide text-center text-lg bg-white flex justify-center items-center">Slide 6</div>
      <div class="swiper-slide text-center text-lg bg-white flex justify-center items-center">Slide 7</div>
      <div class="swiper-slide text-center text-lg bg-white flex justify-center items-center">Slide 8</div>
      <div class="swiper-slide text-center text-lg bg-white flex justify-center items-center">Slide 9</div>
    </div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-pagination"></div>
  </div>

<section class="sambutan py-20 lg:px-40">
    <div
        class="text-center capitalize z-10 relative text-black mb-20 block w-fit mx-auto p-5 bg-[url('../images/rect.png')] bg-no-repeat bg-contain bg-left">
        <h2 class="bg-white font-quicksand-medium">Sambutan Kepala SMP Qur'an Almuanawiyah</h2>
    </div>
    <div class="sambutan-container flex flex-col px-10 md:flex-row md:items-center">
        <div class="foto order-2 w-full text-center md:w-2/5 p-5 ">
            <img src="<?= base_url() ?>public/assets/images/portrait2.jpg" alt="" class="w-full max-w-52 md:max-w-96 mx-auto">
            <p class=""><span class="font-bold ">- Nama -</span><br> Kepala Sekolah SMP Qur'an Al-Muanawiyah</p>
        </div>
        <div class="teks order-1 mb-5 md:w-3/5  overflow-y-scroll max-h-96">
            <h2 class="font-medium mb-1">Assalamu'alaikum Wr.Wb.</h2>
            <p class="text-sm mb-2 indent-4 text-justify">
                Puji syukur kita panjatkan kehadirat Allah SWT atas segala rahmat dan hidayah-Nya, sehingga kita semua
                dapat beraktivitas dengan baik dan dalam keadaan sehat walafiat.
            </p>
            <p class="text-sm mb-2 indent-4 text-justify">
                SMP Qur'an Al-Muanawiyah berkomitmen untuk memberikan pendidikan yang berkualitas, tidak
                hanya dalam bidang akademis, tetapi juga dalam pengembangan karakter dan spiritual siswa-siswinya. Kami
                percaya bahwa dengan pendekatan yang holistik, anak-anak kita akan tumbuh menjadi individu yang
                berakhlak mulia, berilmu, dan siap menghadapi tantangan zaman.
            </p>
            <p class="text-sm mb-2 indent-4 text-justify">
                Visi kami adalah terwujudnya peserta didik yang berjiwa qur'ani dan unggul dalam IPTEK. Untuk mencapai
                visi tersebut, kami terus berinovasi dalam metode pengajaran, meningkatkan kualitas tenaga pendidik,
                serta memperkaya fasilitas belajar.
            </p>
            <p class="text-sm mb-2 indent-4 text-justify">
                Kami sangat mengapresiasi dukungan dari orang tua santri dan seluruh stakeholder pendidikan yang
                telah turut serta membangun lingkungan pendidikan yang kondusif dan harmonis. Kebersamaan dan kolaborasi
                ini merupakan kunci kesuksesan dalam mencetak generasi penerus bangsa yang handal.
            </p>
            <p class="text-sm mb-2 indent-4 text-justify">
                Akhir kata, mari kita bersama-sama melangkah maju untuk mewujudkan cita-cita pendidikan yang luhur.
                Semoga Allah SWT senantiasa meridhai setiap langkah kita. <br>
                Wassalamu'alaikum warahmatullahi wabarakatuh.
            </p>
        </div>
    </div>
</section>


<section class="berita  mx-3 py-20" id="berita">
    <div
        class="text-center capitalize z-10 relative text-black mb-20 block w-fit mx-auto p-5 bg-[url('../images/rect.png')] bg-no-repeat bg-contain bg-left">
        <h2 class="bg-white font-quicksand-medium">Berita & Artikel</h2>
    </div>
    <div class="berita-outer-container flex flex-col md:flex-row">
        <div class="berita-container h-fit w-full">
            <div
                class="berita-card relative bg-cover shadow-[0_0_10px_rgba(0,0,0,0.25)] rounded-md bg-white w-full flex font-serif p-4 border-b-2 border-primary">
                <div class="gambar-berita h-40 aspect-square rounded-md ">
                </div>
                <div class="detail  pl-2 w-full flex flex-col justify-between">
                    <div class="main flex flex-col">
                        <div class="berita-judul font-bold leading-4">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Alias, libero!</div>
                        <!-- <p class="berita-short text-sm max-h-52 overflow-hidden">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia vero repellat doloremque debitis blandriatur sit?</p> -->
                    </div>
                    <div class="footer flex justify-between font-sans items-center">
                        <div class="tanggal text-xxs">01/09/2024</div>
                        <div 
                            class=" baca-selengkapnya text-xs md:text-sm hover:cursor-pointer hover:bg-black bg-primary transition p-2  text-white rounded-md">
                            Baca Selengkapnya</div>
                    </div>
                </div>
            </div>
            <div
                class="berita-card relative bg-cover shadow-[0_0_10px_rgba(0,0,0,0.25)] rounded-md bg-white w-full flex font-serif p-4 border-b-2 border-primary">

                <div class="gambar-berita h-40 aspect-square rounded-md ">
                </div>
                <div class="detail  pl-2 w-full flex flex-col justify-between">
                    <div class="main flex flex-col">
                        <div class="berita-judul font-bold leading-4">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Alias, libero!</div>
                        <!-- <p class="berita-short text-sm max-h-52 overflow-hidden">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia vero repellat doloremque debitis blandriatur sit?</p> -->
                    </div>
                    <div class="footer flex justify-between font-sans items-center">
                        <div class="tanggal text-xxs">01/09/2024</div>
                        <div
                            class=" baca-selengkapnya text-xs md:text-sm hover:cursor-pointer hover:bg-black bg-primary transition p-2  text-white rounded-md">
                            Baca Selengkapnya</div>
                    </div>
                </div>
            </div>
            <div
                class="berita-card relative bg-cover shadow-[0_0_10px_rgba(0,0,0,0.25)] rounded-md bg-white w-full flex font-serif p-4 border-b-2 border-primary">

                <div class="gambar-berita h-40 aspect-square rounded-md ">
                </div>
                <div class="detail  pl-2 w-full flex flex-col justify-between">
                    <div class="main flex flex-col">
                        <div class="berita-judul font-bold leading-4">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Alias, libero!</div>
                        <!-- <p class="berita-short text-sm max-h-52 overflow-hidden">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia vero repellat doloremque debitis blandriatur sit?</p> -->
                    </div>
                    <div class="footer flex justify-between font-sans items-center">
                        <div class="tanggal text-xxs">01/09/2024</div>
                        <div
                            class=" baca-selengkapnya text-xs md:text-sm hover:cursor-pointer hover:bg-black bg-primary transition p-2  text-white rounded-md">
                            Baca Selengkapnya</div>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="berita-populer max-w-full md:max-w-[450px] my-10 shadow-md rounded-md overflow-hidden lg:w-96 md:m-0 md:h-fit md:ml-5 relative">
            <h3 class="block bg-primary text-white p-3 text-sm">Populer</h3>
            <div class="berita-populer-container font-serif">
                <a href="#"
                    class="block py-2 border-b border-primary hover:text-white  px-3 transition hover:bg-black text-xs">
                    Proin faucibus eu massa a tincidunt. Duis et ex non mi semper vehicula.
                </a>
                <a href="#"
                    class="block py-2 border-b border-primary hover:text-white  px-3 transition hover:bg-black text-xs">Lorem
                    ipsum dolor sit amet
                    consectetur adipisicing.</a>
                <a href="#"
                    class="block py-2 border-b border-primary hover:text-white  px-3 transition hover:bg-black text-xs">Lorem
                    ipsum dolor sit amet
                    consectetur adipisicing elit. Consectetur illo, saepe</a>
                <a href="#"
                    class="block py-2 border-b border-primary hover:text-white  px-3 transition hover:bg-black text-xs">Lorem
                    ipsum dolor sit amet
                    consectetur.</a>
                <a href="#"
                    class="block py-2 border-b border-primary hover:text-white  px-3 transition hover:bg-black text-xs">Lorem
                    ipsum dolor sit amet
                    consectetur adipisicing elit. Consectetur illo, saepe</a>
            </div>
        </div>
    </div>
</section>
<section class="galery  py-20 bg-black relative" id="galeri">
    <div class="absolute top-0 bottom-0 right-0 left-0 bg-black opacity-90 z-0"></div>
    <div
        class="text-center capitalize z-10 relative text-black mb-20 block w-fit mx-auto p-5 bg-[url('../images/rect.png')] bg-no-repeat bg-contain bg-left">
        <h2 class="bg-black text-white">Galery</h2>
    </div>
    <div class="galery-container px-10 md:px-40 mx-auto z-10 relative mb-5">
        <div class="rounded-lg galery-element relative bg-[url('../images/1.thumb.png')] overflow-hidden" data-image="1.jpg"
            data-size="normal">
            <div class="overlay w-full h-full bg-black absolute top-0 left-0 flex justify-center items-center">
                <img src="<?= base_url() ?>public/assets/images/loader.svg" class="w-5 h-5 rounded-lg" alt="">
            </div>
            <img src="" class="rounded-md hd w-full h-full object-cover object-center hidden">
        </div>
        <div class="rounded-lg galery-element relative bg-[url('../images/2.thumb.png')]" data-image="2.jpg" data-size="normal">
            <div class="overlay w-full h-full bg-black absolute top-0 left-0 flex justify-center items-center">
                <img src="<?= base_url() ?>public/assets/images/loader.svg" class="w-5 h-5 rounded-lg" alt="">
            </div>
            <img src="" class="rounded-md hd w-full h-full object-cover object-center hidden">

        </div>

        <div class="rounded-lg galery-element relative bg-[url('../images/4.thumb.png')]" data-image="4.jpg" data-size="normal">
            <div class="overlay w-full h-full bg-black absolute top-0 left-0 flex justify-center items-center">
                <img src="<?= base_url() ?>public/assets/images/loader.svg" class="w-5 h-5 rounded-lg" alt="">
            </div>
            <img src="" class="rounded-md hd w-full h-full object-cover object-center hidden">

        </div>
        <div class="rounded-lg galery-element relative bg-[url('../images/3.thumb.png')]" data-image="3.png" data-size="">
            <div class="overlay w-full h-full bg-black absolute top-0 left-0 flex justify-center items-center">
                <img src="<?= base_url() ?>public/assets/images/loader.svg" class="w-5 h-5 rounded-lg" alt="">
            </div>
            <img src="" class="rounded-md hd w-full h-full object-cover object-center hidden">

        </div>
        <div class="rounded-lg galery-element relative bg-[url('../images/5.thumb.png')]" data-image="5.jpg" data-size="large">
            <div class="overlay w-full h-full bg-black absolute top-0 left-0 flex justify-center items-center">
                <img src="<?= base_url() ?>public/assets/images/loader.svg" class="w-5 h-5 rounded-lg" alt="">
            </div>
            <img src="" class="rounded-md hd w-full h-full object-cover object-center hidden">

        </div>
        <div class="rounded-lg galery-element relative bg-[url('../images/4.thumb.png')]" data-image="4.jpg" data-size="normal">
            <div class="overlay w-full h-full bg-black absolute top-0 left-0 flex justify-center items-center">
                <img src="<?= base_url() ?>public/assets/images/loader.svg" class="w-5 h-5 rounded-lg" alt="">
            </div>
            <img src="" class="rounded-md hd w-full h-full object-cover object-center hidden">

        </div>
     

    </div>
    <div class="load-more text-center border w-fit mx-auto hover:cursor-pointer text-white relative z-10">Tampilkan
        lebih banyak ...</div>
</section>

<section class="youtube py-20">
    <div
        class="text-center capitalize z-10 relative text-black mb-20 block w-fit mx-auto p-5 bg-[url('../images/rect.png')] bg-no-repeat bg-contain bg-left">
        <h2 class="bg-white font-quicksand-medium">Youtube SMPQ Almuanawiyah</h2>
    </div>
    <div class="w-full youtube-container grid px-10 md:grid-cols-2 lg:grid-cols-3 gap-5">
        <iframe class="w-full h-60 md:h-40 lg:h-48" src=""
            data-src="https://www.youtube.com/embed/1JrlRcx9I_w?si=Tc5KcPw6Yv2uO0g-" title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        <iframe class="w-full h-60 md:h-40 lg:h-48" src=""
            data-src="https://www.youtube.com/embed/Xc9q3ByeWZs?si=2NMrh7IYEGBmWlY7" title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        <iframe class="w-full h-60 md:h-40 lg:h-48" src=""
            data-src="https://www.youtube.com/embed/D8-R2iIf1UI?si=y_R42yHMe_1HgZkv" title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    </div>
</section>

</div>
</section>
